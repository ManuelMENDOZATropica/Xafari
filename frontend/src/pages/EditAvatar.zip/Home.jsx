export default function Home() {
    return <h1 className="text-2xl font-bold text-center">Bienvenido a Xafari</h1>;
  }
  