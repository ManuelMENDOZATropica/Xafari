export default function Perfil() {
    return <h1 className="text-2xl font-bold text-center">Perfil del Usuario</h1>;
  }
  